# Italy Military Computer Market Dataset

> A compact dataset and supporting documentation for the *Italy Military Computer Market* report.

## About the report
This package provides extracted tables, charts, and metadata from the Italy Military Computer Market report available at NextMSC.

**Report link:** https://www.nextmsc.com/report/italy-military-computer-market-3645

## Files in this package
- `report.pdf` — original report (if included).
- `data/` — CSV / Excel files with extracted data.
- `figures/` — images and chart exports.
- `metadata.json` — dataset schema and provenance.
- `README.md` — quick start guide.

## Example usage
```python
import pandas as pd
df = pd.read_csv("data/market_table.csv")
print(df.head())
```

## Citation
When using this dataset, please cite the original NextMSC report.

## Notes
- This repository is intended as a data companion for research and education.
- Verify numbers against the original report for commercial use.

