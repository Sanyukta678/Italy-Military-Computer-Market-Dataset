# Italy Military Computer Market — Dataset & Report Package

This repository contains the data package and supporting files for the **Italy Military Computer Market** report.

**Report URL:** https://www.nextmsc.com/report/italy-military-computer-market-3645

## Contents

- `report.pdf` — (if present) the full report PDF.
- `data/` — structured data files and tables extracted from the report.
- `metadata.json` — metadata describing the dataset and sources.
- `README.md` — this file.

## License & Use

Files in this package are for reference and research purposes only. Check the original report page for licensing and purchase options.

## How to use

1. Inspect `metadata.json` to understand file fields and provenance.
2. Open `data/` for CSV/Excel tables.
3. Cite the original report when using the data.

